
package examen;

public class AuxiliarDeEnfermeria extends Empleado {
    
    static int NtotalAux;
    boolean Discapacidad;

    public AuxiliarDeEnfermeria(String Categoria, String Nombre, String Servicio, boolean Turnicidad, boolean Discapacidad) {
        super(Categoria, Nombre, Servicio, Turnicidad);
        NtotalAux++;
        this.Discapacidad = Discapacidad;
        generarCodigo(3);
    }

    @Override
    public String toString() {
        return "AuxiliarDeEnfermeria\n" + "Discapacidad=" + (Discapacidad?"si":"no") + super.toString();
    }
    
    @Override
    public double getSFinal() {
        double disc;
        if((this.Discapacidad)){
            disc = (TablaSueldosBase.get(Categoria))*0.03;
        }else{
            disc=0;
        }
        
        return super.getSFinal()+disc;
    }
    
    
}
