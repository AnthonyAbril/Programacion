
package fabrica_mondea_timbre;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Principal {
    
    private static final Scanner sc = new Scanner(System.in);
    private static ArrayList <Dinero> ListaDinero = new ArrayList<>();
    private static final File ficherodinero= new File("/home/alumnot/NetBeansProjects/Tema12/fabrica_mondea_timbre_ficheros/ficherodinero.ddr");
    //private static final File ficherodinero = new File("C:\\Users\\abril\\OneDrive\\Documentos\\JAVA\\NetBeans\\3Evaluacion\\Tema12\\fabrica_mondea_timbre_ficheros\\ficherodinero.ddr");
    
    public static void main(String[] args) {
        try{
            
            CargarListaEmpleados(ficherodinero);
            
            Menu();
            
            GuardarListaEmpleados(ficherodinero);
        }catch(ClassNotFoundException ex){
            System.out.println("");
        }catch(EOFException ex){
            System.out.println("");
        }
    }
    
    public static void titulo(String texto){
        System.out.println("\n"+texto);
        for(int a=1;a<=texto.length();a++){
            System.out.print("*");
        }
        System.out.println("");
    }
    
    public static void Menu(){
        int op=0;
        do{
            try{
                System.out.print("----- OPCIONES --------------"
                        + "\n\t1-Crear objetos"//hecho
                        + "\n\t2-Crear copias de objetos"//hecho
                        + "\n\t3-Mostrar todos los objetos"//hecho
                        + "\n\t4-Comprobar si hay dos objetos iguales, y mostrar un mensaje que lo indique"//hecho
                        + "\n\t5-Ordenar el ArrayList"//hecho
                        + "\n\t6-Buscar objetos"
                        + "\n\t7-Modificar los atributos de dimensión de los objetos"
                        + "\n\t8-Eliminar objetos"
                        + "\n\t9-Salir"
                        + "\n>Elige opcion: ");
                op=sc.nextInt();
                sc.nextLine();

                switch (op) {
                    case 1:
                        CrearObjetos();
                        break;
                    case 2:
                        CopiarObjetos();
                        break;
                    case 3:
                        MostrarObjetos();
                        break;
                    case 4:
                        ComprobarIguales();
                        break;
                    case 5:
                        OrdenarLista();
                        break;
                    case 6:
                        BuscarObjeto();
                        break;
                    case 7:
                        break;
                    case 8:
                        break;
                    default:
                        break;
                }
            }catch(java.util.InputMismatchException ex){
                System.out.println(">El valor debe ser un numero entero\n");
                sc.nextLine();
            }
        }while(op!=9);
    }
    
    public static void CargarListaEmpleados(File archivo)throws ClassNotFoundException, EOFException{
        try{
            FileInputStream fis = new FileInputStream(archivo);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            while(true){
                ListaDinero=(ArrayList <Dinero>)ois.readObject();
            }
        }catch(IOException ex){
            System.out.println(" - - Datos cargados - - ");
        }
    }
    
    public static void GuardarListaEmpleados(File archivo){
        try{
            if(archivo.exists()){
                FileOutputStream fos = new FileOutputStream(archivo,true);
                MiObjectOutputStream moos = new MiObjectOutputStream(fos);
                
                moos.writeObject(ListaDinero);
                
                fos.close();
                moos.close();
            }else{
                FileOutputStream fos = new FileOutputStream(archivo);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                
                oos.writeObject(ListaDinero);
                
                fos.close();
                oos.close();
            }
            
            System.out.println("\n - - Datos guardados - - ");
        }catch(IOException ex){
            System.out.println("Error al guardar los datos");
        }
    }
    
    public static void CrearObjetos(){
        titulo("CREACIÓN DE UN OBJETO");
        int opcion;
        do{
            System.out.print("Elige que quieres crear"
                    + "\n\t1-crear una moneda"
                    + "\n\t2-crear un billete"
                    + "\n>Introduce que quieres crear: ");
            
            opcion = sc.nextInt();
        }while(opcion!=1&&opcion!=2);
        
        //valores comunes
        sc.nextLine();
        System.out.print(">Introduce el valor: ");
        Double valor = sc.nextDouble();
        System.out.print(">Introduce el año de emision: ");
        int año = sc.nextInt();
        
        if(opcion==1){//valores de moneda
            System.out.print(">Introduce el diametro: ");
            Double diametro = sc.nextDouble();
            System.out.print(">Introduce el peso: ");
            Double peso = sc.nextDouble();
        
            ListaDinero.add(new Moneda(valor,año,diametro,peso));
        }else if(opcion==2){//valores de billete
            System.out.print(">Introduce la altura: ");
            Double altura = sc.nextDouble();
            System.out.print(">Introduce la anchura: ");
            Double anchura = sc.nextDouble();
            
            ListaDinero.add(new Billete(valor,año,altura,anchura));
        }
    }
    
    public static void CopiarObjetos(){
        int posicion;
        do{
            System.out.print(">Pon la posicion en la lista del objeto a copiar: ");
            
            posicion = sc.nextInt()-1;
        }while(posicion<0||posicion>ListaDinero.size()-1);
        
        if(ListaDinero.get(posicion) instanceof Moneda){
            ListaDinero.add(new Moneda((Moneda)ListaDinero.get(posicion)));
        }else if(ListaDinero.get(posicion) instanceof Billete){
            ListaDinero.add(new Billete((Billete)ListaDinero.get(posicion)));
        }
        System.out.println("- - Copia Creada - -\n");
    }
    
    public static void MostrarObjetos(){
        titulo("LISTA DE TODOS LOS OBJETOS");
        
        for(int a=0;a<ListaDinero.size();a++){
            System.out.println(ListaDinero.get(a)+"\n");
        }
        
    }
    
    public static void ComprobarIguales(){
        titulo("LISTA DE TODOS LOS OBJETOS");//usar arraylist en la que se guarden los numeros de la posicion en la que se encuentran las repetidas y se repase despues para no repetirse
        
        HashMap<String, Integer> repetidos = new HashMap<>(); //hacemos una lista que tenga los datos y las veces q han salido
        for(int a=0;a<ListaDinero.size();a++){//recorre la lista una sola vez
            
            if(repetidos.containsKey(ListaDinero.get(a).toString())){//si esta en el hashmap
                repetidos.replace(ListaDinero.get(a).toString(), repetidos.get(ListaDinero.get(a).toString()), repetidos.get(ListaDinero.get(a).toString())+1);
            
            }else{//si no esta en el hashmap
                repetidos.put(ListaDinero.get(a).toString(), 1);//metemos el primero con un valor de repetidos 1
                
            }
        }
        
        //recorremos el hashmap
        for (Map.Entry<String, Integer> entry : repetidos.entrySet()) {
            Integer valor = entry.getValue();
            // Hacer algo con cada valor
            System.out.print("El objeto "+entry.getKey());
            if(valor>1)
                System.out.println(" se ha repetido " + valor + " veces");
            else
                System.out.println(" no se repite");
        }
    }
    
    public static void OrdenarLista(){
        Collections.sort(ListaDinero, new Comparator<Dinero>(){
        @Override
        public int compare(Dinero e1, Dinero e2) {
            return e1.compareTo(e2 );
            }
        });
        MostrarObjetos();
    }
    
    public static void BuscarObjeto(){
        
    }
}
